document.addEventListener ( "DOMContentLoaded", handleDocumentLoad )

function handleDocumentLoad ()
{
  var myVideo = document.querySelector ( "video" ); /*This variable identifies the video*/

  var playButton = document.getElementById ( "playPause" ); /*This variable uses the ID "playPause" to find the play button.*/
  playButton.addEventListener( "click", playPauseVideo ); /*This uses an eventlistener to listen for a mouse click on the play button, and pauses/plays the video.*/

  var muteButton = document.getElementById ( "Mute" ); /*This variable uses the ID "Mute" to find the mute button.*/
  muteButton.addEventListener( "click", MuteVideo ); /*This uses an eventlistener to listen for a mouse click on the mute button, and mutes the video.*/

  var stopButton = document.getElementById ( "Stop" ); /*This variable uses the ID "Stop" to find the stop button.*/
  stopButton.addEventListener( "click", StopVideo ); /*This uses an eventlistener to listen for a mouse click on the stop button, and stops the video.*/

  var scrubSlider = document.getElementById ( "seekBar" ); /*This variable uses the ID "seekBar" to find the slider for video length/position.*/
  scrubSlider.addEventListener ( "input", scrubVideo ); /*This uses an eventlistener to listen for the input of the slider being moved and adjusts the video position.*/
  myVideo.addEventListener ( "timeupdate", movePlaySlider );

  var soundSlider = document.getElementById ( "soundSlider" ); /*This variable uses the ID "soundSlider" to find the slider for video volume.*/
  soundSlider.addEventListener ( "input", editAudio ); /*This uses an eventlistener to listen for the input of the slider being moved and adjusts the video volume.*/

  var durationDisplay = document.getElementById ( "durationField" ); /*This variable uses the ID "durationField" to find the field for video duration.*/
  durationDisplay.value = myVideo.duration; /*This uses a value to display the video length*/

  var timeDisplay = document.getElementById ( "timeField" ); /*This variable uses the ID "timeField" to find the field for the current video time.*/
  timeDisplay.value = "00:00"; /*This value displays the current video time.*/

  var speedChanger = document.getElementById ( "speedList" ); /*This variable uses the ID "speedList" to find the drop down list of all the various speed options for the video.*/
  speedChanger.addEventListener ( "input", adjustSpeed ); /*This uses an eventlistener to listen for the input of the selected speed and adjusts the speed.*/

  var speedButton = document.getElementById ( "speed" ); /*This variable uses the ID "speed" to find the Fast Forward button.*/
  speedButton.addEventListener ( "dblclick", returnSpeed );
  speedButton.addEventListener ( "mousedown", increaseSpeed );
  speedButton.addEventListener ( "mouseup", doubleSpeed ); /*These use eventlisteners to listen for a double click, mouse down, or mouse up and change the speed accordingly.*/

  function playPauseVideo() /*This function plays or pauses the video, depending on what button is currently available.*/
  {
    if (myVideo.paused === true) /*Function is boolean so requires true or false.*/
    {
      myVideo.play(); /*Gives the button the function.*/
      playButton.innerHTML = "Pause"; /*Changes caption to pause.*/
    }
    else
    {
      myVideo.pause(); /*Gives the button the function.*/
      playButton.innerHTML = "Play"; /*Changes caption back to play.*/
    }
  }

  function MuteVideo() /*This function mutes or unmutes the video, depending on what button is currently available.*/
  {
    if (myVideo.muted === false) /*Function is boolean so requires true or false.*/
    {
      myVideo.muted=true
      muteButton.innerHTML = "UnMute"; /*Changes caption to UnMute.*/
      soundSlider.value = 0; /*Lowers volume to 0.*/
    }
    else
    {
      myVideo.muted=false;
      muteButton.innerHTML = "Mute"; /*Changes caption to Mute*/
      myVideo.volume = 20; /*Standard volume for video.*/
      soundSlider.value = 60; /*Resets to this value when unmuted.*/
    }
  }

  function StopVideo() /*This function stops the video and resets it to the beginning.*/
  {
    myVideo.pause(); /*Gives the button the function.*/
    playButton.innerHTML = "Play"; /*Changes caption to play.*/
    myVideo.currentTime = 0; /*Resets video back to 00:00.*/
  }

  function scrubVideo() /*This function allows for position of video timeline to be changed.*/
  {
    var scrubTime = myVideo.duration * (scrubSlider.value/100); /*Assigns a value to the duration.*/
    myVideo.currentTime = scrubTime; /*Matches time to current position of scrub slider.*/
  }

  function movePlaySlider() /*This function allows for slider to move so position of video timeline can be changed.*/
  {
    if (myVideo.currentTime >0)
    {
      scrubSlider.value = (myVideo.currentTime/myVideo.duration) * 100; /*The value of the scrub slider correlates to the video time*/
    }
    else
    {
      scrubSlider.value = 0; /*Resets value to the start of the video*/
    }
  }

  function editAudio() /*This function allows the volume to be changed using a slider*/
  {
    myVideo.volume = soundSlider.value/100; /*The value of the slider correlates to the volume.*/
  }


  myVideo.addEventListener ( "durationchange", displayDuration );
  function displayDuration() /*This function displays a timer showcasing the full video length.*/
  {
    var durationDisplay = document.getElementById ( "durationField" );
    var minutes = Math.floor ( myVideo.duration / 60 ); /*Given a whole value*/
    var seconds = Math.floor ( myVideo.duration % 60 ); /*Given the remaining value*/

    if (minutes <10 ) minutes = "0" + minutes; /*A 0 is put infront of the minutes value if it is below 10.*/

    if (seconds <10 ) seconds = "0" + seconds; /*A 0 is put infront of the seconds value if it is below 10.*/

    durationDisplay.value = minutes + ":" + seconds;
  }

  var timeDisplay = document.getElementById ( "timeField" ); /*This function displays a timer showcasing the current video time.*/
  myVideo.addEventListener ( "timeupdate", displayTime );
  function displayTime()
  {
    var minutes = Math.floor ( myVideo.currentTime / 60 ); /*Given a whole value for the current video time.*/
    var seconds = Math.floor ( myVideo.currentTime % 60 ); /*Given the remaining value for that time.*/

    if (minutes <10 ) minutes = "0" + minutes; /*A 0 is put infront of the minutes value if it is below 10.*/

    if (seconds <10) minutes = "0" + minutes; /*A 0 is put infront of the seconds value if it is below 10.*/

    timeDisplay.value = minutes + ":" + seconds;
  }

  function adjustSpeed() /*This function and all below it allow the videos speed to be adjusted depending on the option selected.*/
  {
    var speed = speedChanger.value;
    myVideo.playbackRate = speed;
  }

  function returnSpeed()
  {
    myVideo.playbackRate = 1;
    speedChanger.value = 1;
  }

  function increaseSpeed()
  {
    myVideo.playbackRate = 3;
    speedChanger.value = 3;
  }

  function doubleSpeed()
  {
    myVideo.playbackRate = 2;
    speedChanger.value = 2;
  }
}