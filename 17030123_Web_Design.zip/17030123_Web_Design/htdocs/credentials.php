<?php
// default values for Xampp when accessing your MySQL database:
$dbhost  = 'localhost';
$dbuser  = 'root';
$dbpass  = '';
$dbname  = 'skeleton';
?>