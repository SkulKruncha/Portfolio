<?php

// Things to notice:
// You need to add your Analysis and Design element of the coursework to this script
// There are lots of web-based survey tools out there already.
// It’s a great idea to create trial accounts so that you can research these systems. 
// This will help you to shape your own designs and functionality. 
// Your analysis of competitor sites should follow an approach that you can decide for yourself. 
// Examining each site and evaluating it against a common set of criteria will make it easier for you to draw comparisons between them. 
// You should use client-side code (i.e., HTML5/JavaScript/jQuery) to help you organise and present your information and analysis 
// For example, using tables, bullet point lists, images, hyperlinking to relevant materials, etc.

// execute the header script:
require_once "header.php";

if (!isset($_SESSION['loggedInSkeleton']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}
else
	//Here I included my website design analysis of other competitor websites.
{
	echo "<h1>Design and Analysis</h1>
<br>
<h2>Survey Monkey</h2>
<br>
<br><h3>Layout/Presentation:</h3> The layout of the site is very interesting, as it immediately captures the attention of the user through the sleek, interactive visuals. It also is very user-friendly as the website centre�s text, allowing the user to have an easy time when navigating the website. This is also useful as it allows the user to focus on the survey questions being asked. This also means the survey will not continue unless an answer has been selected. The layout of the surveys is extremely easy to grasp, as all the answers are laid out in front of the user, and they simply only have to click whichever answer appeals to them most. The website�s survey creator offers many different themes for the surveys, all varying in different colours and formats. This does offer the user some varied choice in the layout of their survey, however, it is neglectable to say the least.
<br>
<h3>Ease of use:</h3> The website is easy to use when filling out a survey, and likewise, making one. When filling out the survey the website does everything required and accomplishes this extremely well. The website shows the user what needs to be done by focusing on the questions/answers presented and tells the user if the answer will be accepted or not. The website also has an autofill feature, which greatly increases the websites accessibility for users.
When making the survey, the website is extremely easy to use, however it does have some flaws. When making the form, it is simple to use, and it guides you through the whole process. The website shows what questions are available and allows you to quickly switch between categories quickly. The website also includes various pre-sets for questions. Some settings on the website are hard to understand at first, however, they have pop up boxes that appear to help the user should they be in need of assistance.
<br>
<h3>User Accounts (Log in process/Account set up):</h3> The website�s account creation is simple yet slightly flawed as there is no password requirements, aside from a password already being in use. This can be a potential security breach, as there is no requirement for a password to have case-sensitive characters/numbers. The website also doesn�t tell the user that the password must be 8 characters long. This will mean that users may have to think of multiple passwords before finding one that the website will accept as valid. The account creation process is extremely simple however, as one can use their Google account or Facebook account to create an account, allowing the user to jump straight into the website and get going immediately. This is also helpful as if the user is signed in on Facebook/Google, then the website will automatically sign the user in when they allow the website permissions. These options are extremely useful as most other websites don�t allow these options. The login process for the website is extremely straight forward. 
<br>
<h3>Analysis Tools:</h3> The website provides a variety of tools which are very good for the user. These tools include date charts, which work in the background of the website and collect data from users. The website also allows you to change the look of the graphs and what to show exactly. This allows the analysis to be extremely easy and very in-depth.
<br>
<h2>Checkbox</h2>
<br>
<h3>Layout/Presentation:</h3> This websites layout is similar to SurveyMonkey�s layout, however, the website is easier to navigate, as the text is centred and less cluttered. You are immediately presented with a button suggesting to try the website for free. This captures the user�s attention immediately. The user is then presented with the option of either a cloud-hosted version or an on-premises version of their survey.
<br>
<h3>Ease of use:</h3> The website is easy to use as once the user gets started they are taken on a tour by the website which shows them around and also shows how to use the website. This is extremely helpful for new users as they may be taken aback by the websites features and may not even know where to begin. However while the website is extremely helpful in this regard, it is also very confusing on where to start. The website also doesn�t have as many options as SurveyMonkey.
<br>
<h3>User Accounts (Log in process/Account set up):</h3> The website�s account creation process is simple yet flawed. The website has no limit on the password�s character limit, which is again, just like SurveyMonkey, a potential security breach. The user has the option of choosing a secure Amazon AWS hosting in either the US or Canada. However, this is also extremely flawed as the user must pay for premium services in order to use EU hosting. The user can also use a custom subdomain for their account. This allows easy access to the specific user�s account/surveys.
<br>
<h3>Analysis Tools:</h3> The analysis tools for the website are extremely lacking, as the website seems to struggle sometimes when producing a quick report. The graphs are very basic and don�t really give a lot of information to the user.
<br>
<h2>Google Forms</h2>
<br>
<h3>Layout/Presentation:</h3> The website�s layout is extremely sleek and captivating. This captures the user�s attention immediately. The website has multiple animated features on the website. The website also features a large button suggesting the user to go to create a Google form. The websites survey creation page is also very sleek and easy to navigate; however, it seems a bit cluttered.
<br>
<h3>Ease of use:</h3> The website is extremely easy to use as it features multiple templates for the user to use. The user can either start with a blank template or various other templates ranging from Contact Information, RSVP, and Party Invites. The website also features a tour of the various options, however unlike Checkbox, it is extremely simple/easy to follow. The website also allows real time answers. The websites survey creation is also extremely easy to follow as it allows the user to add videos, images, and other questions at the click of a button. The user can also change the font for both questions and answers and can change the theme colours. The forms are also automatically saved.
<br>
<h3>User Accounts (Log in process/Account set up):</h3> The user account process is easily the simplest of all the websites as the user can immediately jump in by being signed into their Google account, which most users will already be signed into. Therefore, the account creation process is already done, and the user is simply logged in immediately upon entering the site.
<br>
<h3>Analysis Tools:</h3> The analysis tools for the website are sadly limited to just text analysis. This is due to the website not providing the user with any graph�s or charts detailing the data of the user�s surveys. Rather the user just receives the direct response from the user who answered the survey. This is helpful in some cases; however, number data would be much more helpful for the user to determine what their users want."
;
}

// finish off the HTML for this page:
require_once "footer.php";
?>