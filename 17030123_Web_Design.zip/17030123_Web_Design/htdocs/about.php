<?php

// execute the header script:
require_once "header.php";

echo "This is the skeleton code for 2CWK50. See the assignment specification for details of how you need to extend it.<br>You may wish to include a short description of your survey site and how to use the main features it has here.<br><br>";

// finish of the HTML for this page:
require_once "footer.php";

?>