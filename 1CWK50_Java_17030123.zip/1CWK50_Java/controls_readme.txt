Use arrow keys to move left, right, up, and down. The same also applies to the WASD keys.

Copyright Information:

The mainPlayer asset sprite was created by Stephen Challener (Redshrike), and hosted by OpenGameArt.org.

Link: https://opengameart.org/content/tiny-skelly-rpg-enemies-rework

The secondPlayer asset sprite was created by Stephen "Redshrike" Challener as graphic artist, 
William.Thompsonj as contributor, and Charles Gabriel as creator of the sprite base this is made on.
Mandi Paugh as the original artist of Sara and creator.

Link: https://opengameart.org/content/sara-16x18